#!/bin/sh
javac -classpath jfreechart-1.0.13.jar:itext-1.4.3.jar:jcommon-1.0.16.jar *.java