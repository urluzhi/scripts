Updated: Oct. 31, 2006

There are nineteen files of free energies for RNA-RNA interactions.
The derivation of these parameters is in
"Mathews, D. H., Disney, M. D., Childs, J. L., Schroeder, S. J., Zuker,
M. & Turner, D. H. (2004). Incorporating chemical modification constraints
into a dynamic programming algorithm for prediction of RNA secondary structure.
Proc. Natl. Acad. Sci. USA 101, 7287-7292."

Here is a brief summary of what the files contain:

All the parameters used by RNAstructure are for standard free energy 
at 37 degrees C.  Stack.dat contains the nearest neighbor parameters for 
stacking in a helix.  Dangle.dat presents the free energy of dangling ends 
(5 prime or 3 prime).  These energies are used in multibranch and exterior 
loops.  The loop.dat table contains the entropic penalty for closing hairpin, 
internal, and bulge loops.  Each has its own penalty based on length.  
Tstackh.dat gives the free energy of stacking for a terminal mismatch in a 
hairpin loop.  Tstacki.dat gives the free energy of stacking for a terminal 
mismatch in an internal loop.  Tstacki23.dat is used for terminal mismatch 
stacking in internal loops of size 2x3 unpaired nucleotides (and 3x2).  
Tstacki1n.dat is used for terminal mismatch stacking in internal loops of 
size 1xn nucleotides where n>2.  Tstackm.dat is used for terminal stacking 
in a multibranch loop.  Tstack.dat is for terminal mismatch stacking in 
exterior loops, i.e. loops that contain the ends of the sequence.  
Miscloop.dat contains miscellaneous loop parameters.  Int21.dat is a lookup 
table for the free energy of a 2x1 internal loop.  The values presented are 
the total stability of the loop, including the entropic penalty and the 
terminal stack bonus.  Int22.dat is a lookup table for the free energy of a 
2x2 internal loop analogous to the 2x1 internal loop.  Int11.dat is the 
lookup table for single mismatches.  Tloop.dat is the tetraloop bonus table.  
For hairpin loops with four unpaired nucleotides, this table is consulted.  
If the sequence (starting with the 5 prime last paired nucleotide and 
finishing with its 3 prime paired nucleotide) appears in the table, the 
bonus is applied to the hairpin's stability.  Triloop.dat is a lookup 
table for hairpin loops of three.  It is applied analogously to the tetraloop 
table (above).  Also, hexaloop.dat is a lookup table for hairpins of six 
nucleotides.  Coaxial.dat is the free energy of coaxial stacking for two 
helixes with no intervening unpaired nucleotides.  When applied, the top 
nucleotides are the continuous sequence and the bottom nucleotides are 
interrupted by the rest of the multibranch loop or exterior loop.  
Coaxstack.dat is one of the two tables for coaxial stacking with an 
intervening mismatch.  This is the stack with the open backbone.  
Tstackcoax.dat is the second of the tables for coaxial stacking with an 
intervening mismatch.  This is the stack with the continuous backbone.
 
